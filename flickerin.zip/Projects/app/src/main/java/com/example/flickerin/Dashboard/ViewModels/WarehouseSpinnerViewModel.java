package com.example.flickerin.Dashboard.ViewModels;

public class WarehouseSpinnerViewModel {



}
