package com.example.flickerin.Dashboard.Models;

import java.util.ArrayList;

public class WarehouseSpinnerModel {

    ArrayList<String> warehousename;

    public WarehouseSpinnerModel(ArrayList<String> WarehouseName){
        this.warehousename = WarehouseName;
    }

    public void setWarehousename(ArrayList<String> WHName){
        this.warehousename = WHName;
    }

    public ArrayList<String> getWarehousename(){
        return warehousename;
    }


}
